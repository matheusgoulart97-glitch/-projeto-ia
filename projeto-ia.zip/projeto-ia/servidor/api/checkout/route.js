// Checkout dos planos via Mercado Pago.
// Com MERCADOPAGO_ACCESS_TOKEN configurado: cria preferência e redireciona ao checkout.
// Sem token: redireciona de volta com aviso (modo demo).

import { NextResponse } from "next/server";
import { getPlan } from "../../../lib/plans";

export async function GET(req) {
  const { searchParams, origin } = new URL(req.url);
  const planoId = searchParams.get("plano") || "basico";
  const plano = getPlan(planoId);
  const token = process.env.MERCADOPAGO_ACCESS_TOKEN;
  const appUrl = process.env.APP_URL || origin;

  if (plano.priceValue === 0) {
    return NextResponse.redirect(`${appUrl}/dashboard`);
  }

  if (!token) {
    return NextResponse.redirect(`${appUrl}/dashboard?aviso=pagamento&plano=${planoId}`);
  }

  try {
    const res = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        items: [
          {
            title: `Projeto IA — Plano ${plano.name}`,
            description: plano.features.join(" | "),
            quantity: 1,
            unit_price: plano.priceValue,
            currency_id: "BRL",
          },
        ],
        back_urls: {
          success: `${appUrl}/dashboard?pagamento=sucesso&plano=${planoId}`,
          failure: `${appUrl}/dashboard?pagamento=falha`,
          pending: `${appUrl}/dashboard?pagamento=pendente`,
        },
        auto_return: "approved",
      }),
    });
    const data = await res.json();
    if (data?.init_point) {
      return NextResponse.redirect(data.init_point);
    }
    return NextResponse.redirect(`${appUrl}/dashboard?aviso=pagamento&erro=${encodeURIComponent(JSON.stringify(data))}`);
  } catch (e) {
    return NextResponse.redirect(`${appUrl}/dashboard?aviso=pagamento&erro=${encodeURIComponent(e.message)}`);
  }
}