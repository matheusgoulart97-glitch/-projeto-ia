// Webhook do Mercado Pago (notificações de pagamento).
// Configure a URL pública desta rota no painel do Mercado Pago:
//   https://SEU-DOMINIO/api/webhooks/mercadopago
// Aqui registramos a notificação (log). Para ativar planos automaticamente,
// conecte a service_role key e atualize profiles.plan conforme o pagamento.

import { NextResponse } from "next/server";

export async function POST(req) {
  try {
    const body = await req.json();
    console.log("[mercadopago webhook]", JSON.stringify(body).slice(0, 2000));
    // Ex.: body.type === 'payment' -> consultar /v1/payments/{id} e ativar o plano
    return NextResponse.json({ received: true });
  } catch {
    return NextResponse.json({ received: true });
  }
}

export async function GET() {
  return NextResponse.json({ status: "webhook mercadopago ativo" });
}