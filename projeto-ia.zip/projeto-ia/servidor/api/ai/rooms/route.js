// Hook de IA (opcional): recebe uma imagem da página da planta (dataURL) e
// pede à OpenAI (gpt-4o-mini, visão) uma lista aproximada de ambientes em
// coordenadas normalizadas. Experimental — o usuário SEMPRE revisa e ajusta
// os retângulos no editor antes de gerar os pontos.
// Sem OPENAI_API_KEY configurada, responde 501 com instruções.

import { NextResponse } from "next/server";

export async function POST(req) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) {
    return NextResponse.json(
      {
        error: "ia_nao_configurada",
        mensagem:
          "Defina OPENAI_API_KEY no arquivo .env (ou nas variáveis da Vercel) para habilitar a detecção assistida de ambientes. Enquanto isso, marque os ambientes manualmente — leva poucos cliques.",
      },
      { status: 501 }
    );
  }

  try {
    const { image } = await req.json();
    if (!image || !String(image).startsWith("data:image")) {
      return NextResponse.json({ error: "Envie 'image' como dataURL de imagem (JPG/PNG)." }, { status: 400 });
    }

    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text:
                  "Esta é a planta de uma residência. Identifique os ambientes e devolva SOMENTE um JSON válido no formato {\"ambientes\":[{\"nome\":\"Quarto 1\",\"x\":0.05,\"y\":0.10,\"w\":0.30,\"h\":0.25}]} com x,y,w,h NORMALIZADOS (0 a 1) em relação à largura/altura da imagem. Não inclua nenhum texto fora do JSON.",
              },
              { type: "image_url", image_url: { url: image } },
            ],
          },
        ],
        max_tokens: 800,
      }),
    });
    const data = await res.json();
    const texto = data?.choices?.[0]?.message?.content || "";
    const match = texto.match(/\{[\s\S]*\}/);
    if (!match) {
      return NextResponse.json({ error: "Resposta da IA não contém JSON válido.", bruto: texto.slice(0, 500) }, { status: 502 });
    }
    const parsed = JSON.parse(match[0]);
    return NextResponse.json(parsed);
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}