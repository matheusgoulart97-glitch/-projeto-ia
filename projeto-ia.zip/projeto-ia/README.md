# ⚡ Projeto IA — Seu projeto elétrico, mais simples.

Site funcional (MVP completo) para criar **projetos elétricos residenciais com
pontos de luz, interruptores e tomadas** a partir de uma planta em PDF ou
imagem — seguindo o layout enviado (landing page, onboarding, dashboard,
planos, upload, editor de planta e versão mobile).

---

## ✅ O que já funciona neste código

| Recurso | Status |
|---|---|
| Landing page (hero, planos, como funciona, sobre) | ✅ Pronto |
| Cadastro/login de usuários (Supabase Auth) | ✅ Pronto |
| Banco de dados (Postgres/Supabase): usuários, projetos, ambientes, pontos, modelos de referência | ✅ Pronto (schema incluso) |
| Upload da planta (PDF/JPG/PNG, até 10MB) com Storage | ✅ Pronto |
| Editor de planta: visualiza o PDF (pdf.js) e permite marcar ambientes | ✅ Pronto |
| Inserção de **interruptores, tomadas e pontos de luz** com símbolos no estilo NBR 5444 | ✅ Pronto |
| **Sugestão automática de pontos por ambiente** usando seus projetos anteriores como referência (modelos salvos) | ✅ Pronto |
| **Detecção de ambientes por IA (visão)** — opcional, com hook pronto para a OpenAI | ⚠️ Precisa da sua chave |
| Lista de materiais estimada + relatório | ✅ Pronto |
| Exportação em PDF | ✅ Pronto |
| Pagamentos (Mercado Pago: Grátis / Básico R$39,90 / Profissional R$199,00) | ⚠️ Precisa da sua conta |
| Hospedagem de verdade (produção) | ⚠️ Você faz o deploy (passos abaixo) |

> **Transparência sobre a IA:** nenhuma IA consegue, hoje, "ler" 100% correta
> qualquer planta e marcar tudo sozinha de forma confiável. Por isso o sistema
> funciona assim: **você marca o ambiente** (arrastando um retângulo — 2 cliques),
> e a IA/referência **preenche automaticamente os pontos** (interruptores,
> tomadas e luzes) com base nos seus projetos anteriores. Também incluí um
> hook experimental de detecção de ambientes por visão (OpenAI), que sugere os
> retângulos e você confirma. É honesto, funcional e rápido.

---

## 🗂 Estrutura do projeto

```
projeto-ia/
├── app/
│   ├── page.js                 # Landing page
│   ├── login/page.js           # Cadastro / login
│   ├── dashboard/page.js       # Dashboard (meus projetos + planos)
│   ├── dashboard/novo/page.js  # Upload da planta
│   ├── projeto/[id]/page.js    # Editor da planta elétrica
│   ├── api/checkout/route.js   # Checkout Mercado Pago
│   ├── api/ai/rooms/route.js   # Hook de IA (detecção de ambientes)
│   └── api/webhooks/mercadopago/route.js
├── components/ (Logo, PlanCards, Sidebar)
├── lib/ (supabaseClient, symbols, materials, suggestions, plans)
├── supabase/schema.sql         # Crie o banco com 1 clique
├── .env.example                # Onde vão suas chaves
└── package.json
```

---

## 🚀 Como colocar no ar (passo a passo)

### 1. Banco de dados (Supabase) — grátis
1. Crie uma conta em **https://supabase.com** (plano free serve).
2. **New project** → escolha senha e região (South America).
3. Vá em **SQL Editor** → cole todo o conteúdo de `supabase/schema.sql` → **Run**.
4. Vá em **Storage** → crie um bucket chamado **`plantas`** (marque privado).
5. Vá em **Settings → API** e copie:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 2. Configurar as chaves
```bash
cp .env.example .env.local
# edite .env.local com as chaves copiadas
```

### 3. Testar no seu computador
```bash
npm install
npm run dev
# abra http://localhost:3000
```

### 4. Publicar na internet (Vercel) — grátis
1. Suba o projeto no GitHub.
2. Em **https://vercel.com** → **Add New Project** → importe o repositório.
3. Em **Environment Variables**, adicione as mesmas variáveis do `.env.local`.
4. Clique **Deploy** — em ~2 minutos seu site está no ar com HTTPS.
   - Domínio próprio (opcional): Vercel → Settings → Domains (ex.: `projetoia.com.br` ~R$40/ano no registro.br).

### 5. Pagamentos (Mercado Pago — para receber os planos)
1. Crie sua conta em **https://www.mercadopago.com.br**.
2. **Suas integrações → Criar aplicação** → copie o **Access Token de produção**.
3. Coloque em `MERCADOPAGO_ACCESS_TOKEN` (na Vercel e no `.env.local`).
4. Defina `APP_URL=https://seu-site.vercel.app`.
5. No painel do Mercado Pago, configure o **webhook** para:
   `https://seu-site.vercel.app/api/webhooks/mercadopago`
6. Para receber, precisa ativar sua conta como vendedor (dados bancários/CNPJ ou CPF).

> Alternativa: o código é fácil de adaptar para **Stripe** (o arquivo de
> checkout isola toda a lógica de pagamento em um só lugar).

### 6. IA de detecção de ambientes (opcional)
1. Crie uma chave em **https://platform.openai.com** → `OPENAI_API_KEY`.
2. Adicione na Vercel. O botão **"Detectar ambientes (IA)"** do editor passa a sugerir
   os retângulos dos ambientes, que você confirma/ajusta.

---

## 💰 Custos estimados mensais

| Item | Custo |
|---|---|
| Supabase (plano free) | R$ 0 (até 500MB banco + 1GB storage) |
| Vercel (plano Hobby) | R$ 0 |
| OpenAI (só se usar IA) | ~US$ 0,01–0,05 por análise de planta |
| Mercado Pago | Grátis; taxa ~4,99% + R$0,49 por venda |
| Domínio próprio (opcional) | ~R$ 40/ano |
| **Total para começar** | **R$ 0/mês** |

---

## 🔒 Segurança
- Cada usuário só acessa os próprios projetos (**Row Level Security** no Supabase — já configurado no schema).
- As chaves secretas ficam só no servidor (.env / Vercel), nunca no navegador.

## 📌 Próximos passos sugeridos
- Cálculo real de cargas/demanda e dimensionamento de condutores (plano Profissional).
- Desenho dos traçados de circuitos sobre a planta (linhas eletroduto).
- Emissão de ART/RRT integrada.
