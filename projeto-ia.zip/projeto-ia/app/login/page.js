"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Logo from "../../components/Logo";
import { getSupabase } from "../../lib/supabaseClient";

export default function LoginPage() {
  const r = useRouter();
  const sb = getSupabase();
  const [modo, setModo] = useState("entrar");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [nome, setNome] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);

  if (!sb) {
    return (
      <div className="main" style={{ maxWidth: 460, margin: "80px auto" }}>
        <Logo />
        <div className="banner" style={{ marginTop: 20 }}>
          Modo demonstração: as variáveis do Supabase não estão configuradas.
          Defina NEXT_PUBLIC_SUPABASE_URL e NEXT_PUBLIC_SUPABASE_ANON_KEY no arquivo .env
          para ativar login, banco de dados e salvamento de projetos.
        </div>
        <button className="btn btn-primary" style={{ width: "100%" }} onClick={() => r.push("/dashboard?demo=1")}>
          Continuar em modo demonstração →
        </button>
        <div style={{ textAlign: "center", marginTop: 14 }}>
          <Link href="/" className="muted">← Voltar ao início</Link>
        </div>
      </div>
    );
  }

  async function submit(e) {
    e.preventDefault();
    setErro("");
    setCarregando(true);
    try {
      if (modo === "entrar") {
        const { error } = await sb.auth.signInWithPassword({ email, password: senha });
        if (error) throw error;
      } else {
        const { error } = await sb.auth.signUp({ email, password: senha });
        if (error) throw error;
        if (nome) {
          const u = await sb.auth.getUser();
          if (u?.data?.user) {
            await sb.from("profiles").upsert({ id: u.data.user.id, full_name: nome });
          }
        }
      }
      r.push("/dashboard");
    } catch (err) {
      setErro(err.message);
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="main" style={{ maxWidth: 440, margin: "70px auto" }}>
      <Logo />
      <h2 style={{ margin: "22px 0 4px" }}>{modo === "entrar" ? "Entrar" : "Criar conta"}</h2>
      <p className="muted">Seu projeto elétrico, mais simples.</p>
      <form onSubmit={submit}>
        {modo === "criar" && (
          <>
            <label className="lbl">Seu nome</label>
            <input className="input" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Matheus Goulart" />
          </>
        )}
        <label className="lbl">E-mail</label>
        <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" />
        <label className="lbl">Senha</label>
        <input className="input" type="password" required minLength={6} value={senha} onChange={(e) => setSenha(e.target.value)} placeholder="Mínimo 6 caracteres" />
        {erro && <div className="banner" style={{ marginTop: 14 }}>{erro}</div>}
        <button className="btn btn-primary" style={{ width: "100%", marginTop: 18 }} disabled={carregando}>
          {carregando ? "Aguarde..." : modo === "entrar" ? "Entrar" : "Criar conta"}
        </button>
      </form>
      <div style={{ textAlign: "center", marginTop: 16 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => setModo(modo === "entrar" ? "criar" : "entrar")}>
          {modo === "entrar" ? "Não tenho conta — criar agora" : "Já tenho conta — entrar"}
        </button>
      </div>
      <div style={{ textAlign: "center", marginTop: 14 }}>
        <Link href="/" className="muted">← Voltar ao início</Link>
      </div>
    </div>
  );
}