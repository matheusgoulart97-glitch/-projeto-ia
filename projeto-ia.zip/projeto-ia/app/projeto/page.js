"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import Sidebar from "../../components/Sidebar";
import { SYMBOLS, SymbolGlyph, symbolColor, symbolLabel } from "../../lib/symbols";
import { computeMaterials } from "../../lib/materials";
import { suggestPointsForRoom, roomTypeFromName, ROOM_TYPES } from "../../lib/suggestions";
import { getSupabase } from "../../lib/supabaseClient";

const PDFJS_URL = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
const PDFJS_WORKER = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

function EditorInner() {
  const searchParams = useSearchParams();
  const id = searchParams.get("id");
  const sb = getSupabase();
  const [demo, setDemo] = useState(false);
  const [userName, setUserName] = useState("");
  const [projeto, setProjeto] = useState(null);
  const [erro, setErro] = useState("");
  const [aba, setAba] = useState("planta");
  const [modo, setModo] = useState("nenhum"); // nenhum | ambiente | <symbol id>
  const [rooms, setRooms] = useState([]);
  const [points, setPoints] = useState([]);
  const [selRoom, setSelRoom] = useState(null);
  const [selPoint, setSelPoint] = useState(null);
  const [novoAmb, setNovoAmb] = useState(null); // {x,y,w,h} aguardando nome
  const [nomeAmb, setNomeAmb] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [msg, setMsg] = useState("");
  const [page, setPage] = useState(1);
  const [numPages, setNumPages] = useState(1);
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);
  const dragRef = useRef(null);
  const pdfDocRef = useRef(null);

  // ---------- carregar projeto ----------
  useEffect(() => {
    async function load() {
      if (!sb) {
        setDemo(true);
        const lista = JSON.parse(localStorage.getItem("pi_projects") || "[]");
        const p = lista.find((x) => x.id === id);
        if (!p) { setErro("Projeto não encontrado (demo)."); return; }
        setProjeto(p);
        setUserName(localStorage.getItem("pi_name") || "Visitante (demo)");
        setRooms(JSON.parse(localStorage.getItem(`pi_rooms_${id}`) || "[]"));
        setPoints(JSON.parse(localStorage.getItem(`pi_points_${id}`) || "[]"));
        renderFile(localStorage.getItem(`pi_file_${id}`));
        return;
      }
      const { data: u } = await sb.auth.getUser();
      if (!u?.data?.user) { window.location.href = "/login"; return; }
      setUserName(u.data.user.user_metadata?.full_name || u.data.user.email);
      const { data: p } = await sb.from("projects").select("*").eq("id", id).single();
      if (!p) { setErro("Projeto não encontrado."); return; }
      setProjeto(p);
      const [{ data: rs }, { data: ps }] = await Promise.all([
        sb.from("rooms").select("*").eq("project_id", id),
        sb.from("points").select("*").eq("project_id", id),
      ]);
      setRooms((rs || []).map(rel));
      setPoints((ps || []).map(rel));
      if (p.pdf_path) {
        const { data: signed } = await sb.storage.from("plantas").createSignedUrl(p.pdf_path, 3600);
        if (signed?.signedUrl) renderFile(signed.signedUrl);
      }
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  function rel(r) { return { ...r, x: +r.x, y: +r.y, w: +r.w, h: +r.h }; }

  // ---------- renderizar PDF/imagem no canvas ----------
  async function renderFile(url) {
    if (!url) return;
    try {
      if (url.toLowerCase().includes(".pdf") || url.startsWith("data:application/pdf")) {
        await loadPdfJs();
        const doc = await window.pdfjsLib.getDocument(url).promise;
        pdfDocRef.current = doc;
        setNumPages(doc.numPages);
        await renderPdfPage(doc, 1);
      } else {
        await drawImage(url);
      }
    } catch (e) {
      setErro("Não foi possível exibir o arquivo: " + e.message);
    }
  }

  function loadPdfJs() {
    return new Promise((res, rej) => {
      if (window.pdfjsLib) return res();
      const s = document.createElement("script");
      s.src = PDFJS_URL;
      s.onload = () => {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
        res();
      };
      s.onerror = rej;
      document.head.appendChild(s);
    });
  }

  function sizeCanvas(vw, vh) {
    const c = canvasRef.current;
    const maxW = c.parentElement.clientWidth;
    const scale = Math.min(1.4, maxW / vw);
    c.width = Math.floor(vw * scale);
    c.height = Math.floor(vh * scale);
  }

  async function renderPdfPage(doc, n) {
    const pg = await doc.getPage(n);
    const vp1 = pg.getViewport({ scale: 1 });
    sizeCanvas(vp1.width, vp1.height);
    const c = canvasRef.current;
    const vp = pg.getViewport({ scale: c.width / vp1.width });
    await pg.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
  }

  function drawImage(url) {
    return new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => {
        sizeCanvas(img.width, img.height);
        const c = canvasRef.current;
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        res();
      };
      img.onerror = rej;
      img.src = url;
    });
  }

  async function trocarPagina(n) {
    setPage(n);
    if (pdfDocRef.current) await renderPdfPage(pdfDocRef.current, n);
  }

  // ---------- interações no overlay ----------
  function toLocal(e) {
    const r = overlayRef.current.getBoundingClientRect();
    return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
  }

  function onDown(e) {
    if (modo !== "ambiente") return;
    e.preventDefault();
    const p = toLocal(e);
    dragRef.current = { x0: p.x, y0: p.y, x1: p.x, y1: p.y };
  }

  function onMove(e) {
    if (!dragRef.current) return;
    const p = toLocal(e);
    dragRef.current.x1 = p.x;
    dragRef.current.y1 = p.y;
    setNovoAmb({ ...dragRef.current, vivo: true });
  }

  function onUp() {
    const d = dragRef.current;
    dragRef.current = null;
    if (!d) return;
    const x = Math.min(d.x0, d.x1), y = Math.min(d.y0, d.y1);
    const w = Math.abs(d.x1 - d.x0), h = Math.abs(d.y1 - d.y0);
    if (w < 0.02 || h < 0.02) { setNovoAmb(null); return; }
    setNovoAmb({ x, y, w, h });
    setNomeAmb("");
    setModo("nenhum");
  }

  function onOverlayClick(e) {
    if (!modo || modo === "nenhum" || modo === "ambiente") return;
    const p = toLocal(e);
    setPoints((old) => [...old, { id: crypto.randomUUID(), kind: modo, x: p.x, y: p.y, page, room_id: selRoom?.id || null }]);
    setSelPoint(null);
  }

  function confirmarAmbiente() {
    const nome = nomeAmb.trim() || "Ambiente";
    const room = { id: crypto.randomUUID(), name: nome, x: novoAmb.x, y: novoAmb.y, w: novoAmb.w, h: novoAmb.h, page };
    setRooms((o) => [...o, room]);
    setSelRoom(room);
    setNovoAmb(null);
  }

  // ---------- ações ----------
  function sugerirPontos() {
    if (!selRoom) { setMsg("Selecione um ambiente primeiro."); return; }
    let modelos = [];
    if (demo || !sb) {
      modelos = JSON.parse(localStorage.getItem("pi_templates") || "[]");
    }
    const sug = suggestPointsForRoom(selRoom, modelos);
    setPoints((o) => [
      ...o.filter((p) => p.room_id !== selRoom.id),
      ...sug.map(({ id: _drop, ...p }) => ({ ...p, id: crypto.randomUUID() })),
    ]);
    setMsg(`${sug.length} pontos sugeridos para "${selRoom.name}" com base em referências. Ajuste como quiser.`);
  }

  async function detectarAmbientesIA() {
    setMsg("IA: análise de ambientes ainda não configurada. Defina OPENAI_API_KEY no .env e faça o deploy para habilitar (veja README).");
  }

  async function salvar() {
    setSalvando(true);
    setMsg("");
    try {
      if (demo || !sb) {
        localStorage.setItem(`pi_rooms_${id}`, JSON.stringify(rooms));
        localStorage.setItem(`pi_points_${id}`, JSON.stringify(points));
        setMsg("Projeto salvo neste navegador (modo demo).");
      } else {
        const strip = (arr) => arr.map(({ id, sugerido, ...r }) => r);
        await sb.from("rooms").delete().eq("project_id", id);
        await sb.from("points").delete().eq("project_id", id);
        if (rooms.length) await sb.from("rooms").insert(strip(rooms).map((r) => ({ ...r, project_id: id })));
        if (points.length) await sb.from("points").insert(strip(points).map((p) => ({ ...p, project_id: id })));
        setMsg("Projeto salvo no banco de dados!");
      }
    } catch (e) {
      setMsg("Erro ao salvar: " + e.message);
    }
    setSalvando(false);
  }

  async function salvarComoModelo() {
    if (!selRoom) { setMsg("Selecione um ambiente para salvá-lo como modelo."); return; }
    const tipo = roomTypeFromName(selRoom.name);
    const pts = points.filter((p) => p.room_id === selRoom.id).map((p) => ({
      kind: p.kind,
      fx: +((p.x - selRoom.x) / selRoom.w).toFixed(3),
      fy: +((p.y - selRoom.y) / selRoom.h).toFixed(3),
    }));
    const modelo = { name: selRoom.name, room_type: tipo, payload: { pontos: pts } };
    if (demo || !sb) {
      const t = JSON.parse(localStorage.getItem("pi_templates") || "[]").filter((x) => x.room_type !== tipo);
      t.push(modelo);
      localStorage.setItem("pi_templates", JSON.stringify(t));
      setMsg(`Modelo do ambiente "${selRoom.name}" salvo! Novos projetos do mesmo tipo usarão esta referência.`);
    } else {
      const { data: u } = await sb.auth.getUser();
      await sb.from("reference_templates").insert({ user_id: u.data.user.id, name: selRoom.name, room_type: tipo, payload: { pontos: pts } });
      setMsg(`Modelo "${selRoom.name}" salvo como referência para a IA!`);
    }
  }

  function excluirSelecionados() {
    if (selPoint) { setPoints((o) => o.filter((p) => p.id !== selPoint.id)); setSelPoint(null); return; }
    if (selRoom) {
      setRooms((o) => o.filter((r) => r.id !== selRoom.id));
      setPoints((o) => o.filter((p) => p.room_id !== selRoom.id));
      setSelRoom(null);
    }
  }

  // ---------- exportar PDF (janela de impressão) ----------
  function baixarPdf() {
    const mats = computeMaterials(points);
    const w = window.open("", "_blank");
    const roomsHtml = rooms.map((r) => {
      const pts = points.filter((p) => p.room_id === r.id);
      return `<tr><td>${r.name}</td><td>${pts.map((p) => symbolLabel(p.kind)).join(", ") || "—"}</td></tr>`;
    }).join("");
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Projeto IA — ${projeto?.name || ""}</title>
      <style>body{font-family:Arial;padding:32px;color:#111}h1{margin:0}table{width:100%;border-collapse:collapse;margin-top:12px}
      td,th{border:1px solid #999;padding:8px;text-align:left;font-size:13px}th{background:#eee}
      .leg{display:flex;gap:16px;flex-wrap:wrap;margin:14px 0}.leg span{font-size:12px}
      .sw{display:inline-block;width:12px;height:12px;border-radius:50%;margin-right:4px;vertical-align:middle}</style></head><body>
      <h1>Projeto elétrico — ${projeto?.name || "Projeto"}</h1>
      <p>Gerado por Projeto IA em ${new Date().toLocaleDateString("pt-BR")} · Página analisada: ${page}</p>
      <h3>Legenda de símbolos (NBR 5444 — representação simplificada)</h3>
      <div class="leg">${SYMBOLS.map((s) => `<span><span class="sw" style="background:${s.color}"></span>${s.label}</span>`).join("")}</div>
      <h3>Ambientes e pontos</h3><table><tr><th>Ambiente</th><th>Pontos</th></tr>${roomsHtml || "<tr><td colspan=2>Nenhum ambiente marcado</td></tr>"}</table>
      <h3>Lista de materiais (estimativa)</h3>
      <table><tr><th>Item</th><th>Quantidade</th></tr>${mats.items.map((i) => `<tr><td>${i.item}</td><td>${i.quantidade}</td></tr>`).join("")}</table>
      <p style="font-size:11px;color:#666">Documento estimado gerado automaticamente. A responsabilidade técnica (ART/RRT) é do profissional habilitado.</p>
      <script>window.onload=()=>window.print()</script></body></html>`);
    w.document.close();
  }

  // ---------- render ----------
  const mats = computeMaterials(points);
  const pontosAmbiente = selRoom ? points.filter((p) => p.room_id === selRoom.id) : [];
  const rectNovo = novoAmb?.vivo ? (
    <div style={{
      position: "absolute", left: `${novoAmb.x * 100}%`, top: `${novoAmb.y * 100}%`,
      width: `${(novoAmb.x1 - novoAmb.x) * 100}%`, height: `${(novoAmb.y1 - novoAmb.y) * 100}%`,
      border: "2px dashed var(--blue-2)", background: "rgba(47,107,255,0.1)", zIndex: 4,
    }} />
  ) : null;

  return (
    <div className="app" style={{ gridTemplateColumns: "240px 1fr" }}>
      <Sidebar userName={userName} demo={demo} />
      <main style={{ padding: 0 }}>
        <div className="editor-top">
          <Link href="/dashboard" className="muted">←</Link>
          <strong>Projeto — {projeto?.name || "..."}</strong>
          <div style={{ display: "flex", gap: 8 }}>
            {["planta", "materiais", "relatorio"].map((t) => (
              <button key={t} className={`tab ${aba === t ? "active" : ""}`} onClick={() => setAba(t)}>
                {t === "planta" ? "Planta Elétrica" : t === "materiais" ? "Lista de Materiais" : "Relatório"}
              </button>
            ))}
          </div>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <button className="btn btn-ghost btn-sm" onClick={salvar} disabled={salvando}>{salvando ? "Salvando..." : "💾 Salvar"}</button>
            <button className="btn btn-primary btn-sm" onClick={baixarPdf}>Baixar PDF ⤓</button>
          </div>
        </div>

        {erro && <div style={{ padding: 16 }}><div className="banner">{erro}</div></div>}
        {msg && <div style={{ padding: "12px 20px 0" }}><div className="banner" style={{ background: "rgba(47,107,255,.12)", borderColor: "rgba(77,139,255,.5)", color: "#bcd2ff" }}>{msg}</div></div>}

        {aba === "planta" && (
          <div className="editor-wrap">
            <div>
              {/* paleta */}
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
                <button className={`btn btn-sm ${modo === "ambiente" ? "btn-primary" : "btn-ghost"}`} onClick={() => { setModo("ambiente"); setSelRoom(null); setSelPoint(null); }}>
                  ▭ Marcar ambiente
                </button>
                <button className="btn btn-ghost btn-sm" onClick={detectarAmbientesIA}>✨ Detectar ambientes (IA)</button>
                {SYMBOLS.map((s) => (
                  <button key={s.id} className={`btn btn-sm ${modo === s.id ? "btn-primary" : "btn-ghost"}`}
                    onClick={() => { setModo(s.id); setSelRoom(null); setSelPoint(null); }}
                    title={s.label}>
                    <SymbolGlyph kind={s.id} /> {s.label}
                  </button>
                ))}
              </div>

              {/* canvas + overlay */}
              <div className="canvas-holder">
                <canvas ref={canvasRef} style={{ display: "block", width: "100%" }} />
                {numPages > 1 && (
                  <div style={{ position: "absolute", left: 10, bottom: 10, zIndex: 5, display: "flex", gap: 6, alignItems: "center" }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => trocarPagina(Math.max(1, page - 1))}>◀</button>
                    <span style={{ fontSize: 12, background: "rgba(11,19,43,.8)", padding: "4px 8px", borderRadius: 8 }}>{page}/{numPages}</span>
                    <button className="btn btn-ghost btn-sm" onClick={() => trocarPagina(Math.min(numPages, page + 1))}>▶</button>
                  </div>
                )}
                <div className="legend">
                  <strong style={{ fontSize: 12 }}>Legenda</strong>
                  {SYMBOLS.map((s) => (
                    <div className="legend-row" key={s.id}>
                      <SymbolGlyph kind={s.id} /> {s.label}
                    </div>
                  ))}
                </div>
                <div
                  ref={overlayRef}
                  style={{ position: "absolute", inset: 0, zIndex: 2, cursor: modo === "ambiente" ? "crosshair" : modo !== "nenhum" ? "copy" : "default" }}
                  onMouseDown={onDown}
                  onMouseMove={onMove}
                  onMouseUp={onUp}
                  onClick={onOverlayClick}
                >
                  {rooms.filter((r) => (r.page || 1) === page).map((r) => (
                    <div key={r.id} className={`room-label ${selRoom?.id === r.id ? "sel" : ""}`}
                      style={{ left: `${r.x * 100}%`, top: `${r.y * 100}%`, width: `${r.w * 100}%`, height: `${r.h * 100}%` }}
                      onClick={(e) => { e.stopPropagation(); setSelRoom(r); setSelPoint(null); setModo("nenhum"); }}>
                      {r.name}
                    </div>
                  ))}
                  {points.filter((p) => (p.page || 1) === page).map((p) => (
                    <span key={p.id} className={`point-el ${selPoint?.id === p.id ? "sel" : ""}`}
                      style={{ left: `${p.x * 100}%`, top: `${p.y * 100}%` }}
                      title={symbolLabel(p.kind)}
                      onClick={(e) => { e.stopPropagation(); setSelPoint(p); setSelRoom(null); setModo("nenhum"); }}>
                      <SymbolGlyph kind={p.kind} />
                    </span>
                  ))}
                  {rectNovo}
                </div>
              </div>

              {/* modal nome do ambiente */}
              {novoAmb && !novoAmb.vivo && (
                <div className="card" style={{ marginTop: 12 }}>
                  <h3>Nome do ambiente</h3>
                  <div style={{ display: "flex", gap: 8 }}>
                    <input className="input" autoFocus value={nomeAmb} onChange={(e) => setNomeAmb(e.target.value)} placeholder="Ex.: Quarto 1, Sala, Cozinha..." onKeyDown={(e) => e.key === "Enter" && confirmarAmbiente()} />
                    <button className="btn btn-primary btn-sm" onClick={confirmarAmbiente}>OK</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setNovoAmb(null)}>Cancelar</button>
                  </div>
                  <p className="muted" style={{ fontSize: 12, marginBottom: 0 }}>Tipos reconhecidos: {ROOM_TYPES.join(", ")}</p>
                </div>
              )}
            </div>

            {/* painel direito */}
            <div style={{ display: "grid", gap: 14, alignContent: "start" }}>
              <div className="card">
                <h3>Ambiente selecionado</h3>
                {selRoom ? (
                  <>
                    <strong>{selRoom.name}</strong>
                    <p className="muted">{pontosAmbiente.length} ponto(s) neste ambiente</p>
                    <button className="btn btn-primary btn-sm" style={{ width: "100%", marginBottom: 8 }} onClick={sugerirPontos}>✨ Sugerir pontos (referência)</button>
                    <button className="btn btn-ghost btn-sm" style={{ width: "100%", marginBottom: 8 }} onClick={salvarComoModelo}>📌 Salvar como modelo</button>
                    <button className="btn btn-ghost btn-sm" style={{ width: "100%" }} onClick={excluirSelecionados}>🗑 Excluir ambiente</button>
                  </>
                ) : selPoint ? (
                  <>
                    <strong>{symbolLabel(selPoint.kind)}</strong>
                    <p className="muted">Ponto marcado na planta</p>
                    <button className="btn btn-ghost btn-sm" style={{ width: "100%" }} onClick={excluirSelecionados}>🗑 Remover ponto</button>
                  </>
                ) : (
                  <p className="muted">Clique em um ambiente ou ponto na planta para selecionar.</p>
                )}
              </div>
              <div className="card">
                <h3>Lista de Materiais</h3>
                <table className="mat-table">
                  <thead><tr><th>Item</th><th>Quantidade</th></tr></thead>
                  <tbody>
                    {mats.items.map((i) => (
                      <tr key={i.item}><td>{i.item}</td><td>{i.quantidade}</td></tr>
                    ))}
                  </tbody>
                </table>
                <p className="muted" style={{ fontSize: 11.5, marginTop: 8 }}>Estimativa automática — não substitui cálculo técnico.</p>
              </div>
            </div>
          </div>
        )}

        {aba === "materiais" && (
          <div style={{ padding: 20 }}>
            <div className="card" style={{ maxWidth: 640 }}>
              <h3>Lista de Materiais (estimativa)</h3>
              <table className="mat-table">
                <thead><tr><th>Item</th><th>Quantidade</th></tr></thead>
                <tbody>
                  {mats.items.map((i) => (
                    <tr key={i.item}><td>{i.item}</td><td>{i.quantidade}</td></tr>
                  ))}
                </tbody>
              </table>
              <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
                <button className="btn btn-primary" onClick={baixarPdf}>Baixar PDF ⤓</button>
                <button className="btn btn-ghost" onClick={salvar}>💾 Salvar projeto</button>
              </div>
            </div>
          </div>
        )}

        {aba === "relatorio" && (
          <div style={{ padding: 20 }}>
            <div className="card" style={{ maxWidth: 720 }}>
              <h3>Relatório do projeto</h3>
              <p className="muted">
                {rooms.length} ambiente(s) · {points.length} ponto(s) elétrico(s) · {mats.resumo.tomadas} tomadas ·{" "}
                {mats.resumo.interruptores} interruptores · {mats.resumo.luzes} pontos de luz
              </p>
              <table className="mat-table">
                <thead><tr><th>Ambiente</th><th>Pontos definidos</th></tr></thead>
                <tbody>
                  {rooms.map((r) => (
                    <tr key={r.id}>
                      <td>{r.name}</td>
                      <td>{points.filter((p) => p.room_id === r.id).map((p) => symbolLabel(p.kind)).join(", ") || "—"}</td>
                    </tr>
                  ))}
                  {rooms.length === 0 && <tr><td colSpan={2} className="muted">Nenhum ambiente marcado ainda.</td></tr>}
                </tbody>
              </table>
              <p className="muted" style={{ fontSize: 12 }}>
                Cálculos de cargas, circuitos, cabos e disjuntores detalhados fazem parte do plano Profissional.
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default function EditorProjeto() {
  return (
    <Suspense fallback={<div style={{ padding: 30 }} className="muted">Carregando editor...</div>}>
      <EditorInner />
    </Suspense>
  );
}