import "./globals.css";

export const metadata = {
  title: "Projeto IA — Seu projeto elétrico, mais simples.",
  description:
    "Transforme sua planta em um projeto elétrico com pontos de luz, interruptores, tomadas e lista de materiais.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
