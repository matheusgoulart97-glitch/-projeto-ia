import Link from "next/link";
import Logo from "../components/Logo";
import PlanCards from "../components/PlanCards";

export default function Home() {
  return (
    <div>
      <div className="container">
        <nav className="nav">
          <Logo />
          <div className="nav-links">
            <a href="#inicio">Início</a>
            <a href="#planos">Planos</a>
            <a href="#como">Como funciona</a>
            <a href="#sobre">Sobre</a>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <Link href="/login" className="btn btn-ghost">Entrar</Link>
            <Link href="/login" className="btn btn-primary">Começar agora</Link>
          </div>
        </nav>

        <section className="hero" id="inicio">
          <div>
            <h1>
              Projeto elétrico
              <br />
              com <span className="accent">inteligência.</span>
            </h1>
            <p>
              Transforme sua planta em um projeto completo, com pontos elétricos,
              lista de materiais e muito mais. Tudo de forma rápida, simples e segura.
            </p>
            <div className="pills">
              <span className="pill"><span className="dot">⚡</span> Mais agilidade no seu projeto</span>
              <span className="pill"><span className="dot">🛡️</span> Economia de tempo e dinheiro</span>
              <span className="pill"><span className="dot">✅</span> Resultados confiáveis</span>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <Link href="/login" className="btn btn-primary">Começar agora →</Link>
              <a href="#como" className="btn btn-ghost">▷ Ver como funciona</a>
            </div>
          </div>

          <div className="hero-art">
            <div className="mock-floor">
              <div className="mock-room" style={{ left: 0, top: 0, width: "48%", height: "46%" }} />
              <div className="mock-room" style={{ right: 0, top: 0, width: "50%", height: "40%" }} />
              <div className="mock-room" style={{ left: 0, bottom: 0, width: "40%", height: "50%" }} />
              <div className="mock-room" style={{ right: 0, bottom: 0, width: "58%", height: "56%" }} />
              <span className="mock-pin" style={{ left: "22%", top: "20%", color: "#fbbf24", background: "#fbbf24" }} />
              <span className="mock-pin" style={{ left: "70%", top: "18%", color: "#ef4444", background: "#ef4444" }} />
              <span className="mock-pin" style={{ left: "35%", top: "70%", color: "#38bdf8", background: "#38bdf8" }} />
              <span className="mock-pin" style={{ left: "78%", top: "62%", color: "#fbbf24", background: "#fbbf24" }} />
            </div>
          </div>
        </section>

        <section className="section" id="planos">
          <h2>Planos</h2>
          <p className="sub">Do esboço gratuito ao projeto profissional completo.</p>
          <PlanCards />
        </section>

        <section className="section" id="como">
          <h2>Como funciona</h2>
          <p className="sub">Três passos simples, em poucos minutos.</p>
          <div className="steps">
            <div className="card">
              <div className="step-num">1</div>
              <h3>Envie sua planta</h3>
              <p className="muted">
                Suba o PDF ou imagem da sua planta arquitetônica (JPG, PNG ou PDF).
              </p>
            </div>
            <div className="card">
              <div className="step-num">2</div>
              <h3>Marque os ambientes</h3>
              <p className="muted">
                Identifique cada ambiente (quarto, sala, cozinha...) e use os modelos
                dos seus projetos anteriores ou a ajuda da IA para posicionar os pontos.
              </p>
            </div>
            <div className="card">
              <div className="step-num">3</div>
              <h3>Receba o projeto</h3>
              <p className="muted">
                Visualize a planta elétrica com símbolos, gere a lista de materiais e
                baixe tudo em PDF.
              </p>
            </div>
          </div>
        </section>

        <section className="section" id="sobre">
          <h2>Sobre</h2>
          <p className="sub" style={{ maxWidth: 700 }}>
            O Projeto IA foi criado para eletricistas, projetistas, arquitetos e
            engenheiros que precisam agilizar a elaboração de projetos elétricos
            residenciais — com foco em pontos de luz, interruptores e tomadas,
            usando símbolos compatíveis com a representação da NBR 5444.
          </p>
        </section>

        <footer className="footer">
          <Logo small /> — Seu projeto elétrico, mais simples.
        </footer>
      </div>
    </div>
  );
}
