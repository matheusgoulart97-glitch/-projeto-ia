"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Sidebar from "../../../components/Sidebar";
import { getSupabase } from "../../../lib/supabaseClient";

export default function NovoProjeto() {
  const sb = getSupabase();
  const [demo, setDemo] = useState(false);
  const [userName, setUserName] = useState("");
  const [nome, setNome] = useState("");
  const [arquivo, setArquivo] = useState(null);
  const [tipo, setTipo] = useState("arquitetonica");
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState("");
  const fileRef = useRef(null);

  useEffect(() => {
    const qs = new URLSearchParams(window.location.search);
    if (qs.get("demo") === "1") setDemo(true);
    async function load() {
      if (!sb) {
        setDemo(true);
        setUserName(localStorage.getItem("pi_name") || "Visitante (demo)");
        return;
      }
      const { data: u } = await sb.auth.getUser();
      if (!u?.data?.user) {
        window.location.href = "/login";
        return;
      }
      setUserName(u.data.user.user_metadata?.full_name || u.data.user.email);
    }
    load();
  }, [sb]);

  async function salvar() {
    if (!arquivo) {
      setErro("Envie o arquivo da planta (PDF, JPG ou PNG).");
      return;
    }
    setErro("");
    setSalvando(true);
    try {
      const nomeProjeto = nome.trim() || `Projeto ${new Date().toLocaleDateString("pt-BR")}`;
      if (demo || !sb) {
        const lista = JSON.parse(localStorage.getItem("pi_projects") || "[]");
        const id = crypto.randomUUID();
        lista.unshift({ id, name: nomeProjeto, project_type: tipo, created_at: new Date().toISOString(), demo: true });
        localStorage.setItem("pi_projects", JSON.stringify(lista));
        // guarda o arquivo localmente para o editor de demo
        const reader = new FileReader();
        reader.onload = () => {
          localStorage.setItem(`pi_file_${id}`, reader.result);
          window.location.href = `/projeto/${id}`;
        };
        reader.readAsDataURL(arquivo);
        return;
      }
      const { data: u } = await sb.auth.getUser();
      const uid = u.data.user.id;
      const path = `${uid}/${Date.now()}_${arquivo.name.replace(/\s+/g, "_")}`;
      const { error: upErr } = await sb.storage.from("plantas").upload(path, arquivo, { upsert: true });
      if (upErr) throw upErr;
      const { data: proj, error: insErr } = await sb
        .from("projects")
        .insert({ user_id: uid, name: nomeProjeto, project_type: tipo, pdf_path: path, status: "em_edicao" })
        .select()
        .single();
      if (insErr) throw insErr;
      window.location.href = `/projeto/${proj.id}`;
    } catch (e) {
      setErro(e.message);
      setSalvando(false);
    }
  }

  return (
    <div className="app">
      <Sidebar userName={userName} demo={demo} />
      <main className="main">
        <Link href="/dashboard" className="muted">← Voltar</Link>
        <div className="editor-wrap" style={{ gridTemplateColumns: "minmax(0,1fr) 280px", marginTop: 16 }}>
          <div className="card">
            <h2 style={{ margin: 0 }}>Novo projeto</h2>
            <p className="muted">Envie sua planta e escolha o tipo de projeto.</p>

            <label className="lbl">Nome do projeto</label>
            <input className="input" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: Casa Residencial — Centro" />

            <div style={{ marginTop: 16 }} className="dropzone"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files?.[0]) setArquivo(e.dataTransfer.files[0]);
              }}>
              <div style={{ fontSize: 34 }}>☁️</div>
              {arquivo ? (
                <strong style={{ color: "#eef2ff" }}>{arquivo.name}</strong>
              ) : (
                <>
                  <strong style={{ color: "#eef2ff" }}>Arraste sua planta aqui</strong>
                  <div>ou clique para selecionar</div>
                </>
              )}
              <div style={{ fontSize: 12, marginTop: 6 }}>Formatos aceitos: PDF, JPG, PNG (máx. 10MB)</div>
              <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png" hidden
                onChange={(e) => setArquivo(e.target.files?.[0] || null)} />
            </div>

            <label className="lbl">Tipo de projeto</label>
            <div className={`radio-row ${tipo === "arquitetonica" ? "sel" : ""}`} onClick={() => setTipo("arquitetonica")}>
              <span>⭕</span>
              <span>
                <strong>Planta arquitetônica</strong>
                <div className="muted">Sem pontos elétricos</div>
              </span>
            </div>
            <div className={`radio-row ${tipo === "eletrico" ? "sel" : ""}`} onClick={() => setTipo("eletrico")}>
              <span>🔵</span>
              <span>
                <strong>Projeto elétrico</strong>
                <div className="muted">Com pontos já definidos</div>
              </span>
            </div>

            {erro && <div className="banner" style={{ marginTop: 14 }}>{erro}</div>}
            <button className="btn btn-primary" style={{ width: "100%", marginTop: 18 }} onClick={salvar} disabled={salvando}>
              {salvando ? "Enviando..." : "Continuar →"}
            </button>
          </div>

          <div style={{ display: "grid", gap: 14, alignContent: "start" }}>
            <div className="card"><strong>⏱ Rápido</strong><p className="muted">Em poucos minutos você recebe seu projeto.</p></div>
            <div className="card"><strong>🛡 Seguro</strong><p className="muted">Seus arquivos são protegidos e não são compartilhados.</p></div>
            <div className="card"><strong>🎧 Suporte</strong><p className="muted">Dúvidas? Nossa equipe está aqui para te ajudar.</p></div>
          </div>
        </div>
      </main>
    </div>
  );
}