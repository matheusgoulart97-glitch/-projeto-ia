"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import Sidebar from "../../components/Sidebar";
import PlanCards from "../../components/PlanCards";
import { getSupabase } from "../../lib/supabaseClient";

export default function Dashboard() {
  const sb = getSupabase();
  const [demo, setDemo] = useState(false);
  const [userName, setUserName] = useState("");
  const [projects, setProjects] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [aviso, setAviso] = useState("");

  useEffect(() => {
    const qs = new URLSearchParams(window.location.search);
    if (qs.get("aviso") === "demo-plano") {
      setAviso("Os planos pagos (com pagamento via Mercado Pago) funcionam na versão publicada com as chaves configuradas — veja o passo a passo no README. Nesta demonstração, use o plano Grátis.");
    }
    async function load() {
      if (!sb) {
        setDemo(true);
        const locais = JSON.parse(localStorage.getItem("pi_projects") || "[]");
        setProjects(locais);
        setUserName(localStorage.getItem("pi_name") || "Visitante (demo)");
        setCarregando(false);
        return;
      }
      const { data: u } = await sb.auth.getUser();
      if (!u?.data?.user) {
        window.location.href = "/login";
        return;
      }
      const meta = u.data.user.user_metadata || {};
      setUserName(meta.full_name || u.data.user.email || "Usuário");
      const { data } = await sb
        .from("projects")
        .select("*")
        .order("created_at", { ascending: false });
      setProjects(data || []);
      setCarregando(false);
    }
    load();
  }, [sb]);

  const isNovo = false; // /dashboard/novo é página separada

  return (
    <div className="app">
      <Sidebar userName={userName} demo={demo} />
      <main className="main">
        {demo && (
          <div className="banner">
            Modo demonstração: dados salvos apenas neste navegador. Configure o
            Supabase (veja o README) para ter banco de dados real, login e hospedagem dos PDFs.
          </div>
        )}
        {aviso && <div className="banner">{aviso}</div>}
        <h2 style={{ margin: 0 }}>Olá, {userName.split(" ")[0]}!</h2>
        <p className="muted">Vamos transformar sua planta em um projeto elétrico.</p>

        <div style={{ display: "flex", gap: 12, margin: "18px 0 26px" }}>
          <Link href="/dashboard/novo" className="btn btn-primary">➕ Novo projeto</Link>
          <a href="#planos" className="btn btn-ghost">Ver planos</a>
        </div>

        <section id="projetos" className="section" style={{ paddingTop: 10 }}>
          <h2 style={{ fontSize: 20 }}>Meus projetos</h2>
          {carregando ? (
            <p className="muted">Carregando...</p>
          ) : projects.length === 0 ? (
            <div className="card">
              <h3>Nenhum projeto ainda</h3>
              <p className="muted">Envie sua primeira planta para começar.</p>
              <Link href="/dashboard/novo" className="btn btn-primary btn-sm">Criar meu primeiro projeto</Link>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16 }}>
              {projects.map((p) => (
                <Link key={p.id} href={`/projeto/${p.id}`} className="card" style={{ display: "block" }}>
                  <h3>{p.name}</h3>
                  <p className="muted">
                    {p.project_type === "eletrico" ? "Projeto elétrico" : "Planta arquitetônica"} ·{" "}
                    {new Date(p.created_at).toLocaleDateString("pt-BR")}
                  </p>
                  <span className="muted">Abrir editor →</span>
                </Link>
              ))}
            </div>
          )}
        </section>

        <section id="planos" className="section">
          <h2 style={{ fontSize: 20 }}>Planos</h2>
          <p className="sub">Escolha o plano ideal para o seu volume de projetos.</p>
          <PlanCards onChoose={(id) => {
            if (demo) {
              window.location.href = "/dashboard?aviso=demo-plano";
              return;
            }
            window.location.href = `/api/checkout?plano=${id}`;
          }} />
        </section>

        <section id="configs" className="section">
          <h2 style={{ fontSize: 20 }}>Configurações</h2>
          <div className="card">
            <h3>Modelos dos seus projetos</h3>
            <p className="muted">
              Ao finalizar um projeto, você pode salvá-lo como modelo. Os novos
              projetos usam esses modelos como referência para sugerir pontos por ambiente.
            </p>
          </div>
        </section>

        <section id="suporte" className="section" style={{ paddingBottom: 60 }}>
          <h2 style={{ fontSize: 20 }}>Suporte</h2>
          <div className="card">
            <h3>Precisa de ajuda?</h3>
            <p className="muted">
              Dúvidas sobre o editor, planos ou seu projeto? Fale com a equipe —
              estamos aqui para te ajudar em todas as etapas.
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}