"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import Logo from "./Logo";
import { getSupabase } from "../lib/supabaseClient";

const items = [
  { href: "/dashboard", label: "Início", icon: "🏠" },
  { href: "/dashboard/novo", label: "Novo projeto", icon: "➕" },
  { href: "/dashboard", label: "Meus projetos", icon: "📁", anchor: "projetos" },
  { href: "/dashboard", label: "Planos", icon: "💳", anchor: "planos" },
  { href: "/dashboard", label: "Configurações", icon: "⚙️", anchor: "configs" },
  { href: "/dashboard", label: "Suporte", icon: "🎧", anchor: "suporte" },
];

export default function Sidebar({ userName, demo }) {
  const path = usePathname();
  const r = useRouter();
  const sb = getSupabase();
  const iniciais = (userName || "U")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  async function sair() {
    if (sb) await sb.auth.signOut();
    r.push("/");
  }

  return (
    <aside className="sidebar">
      <div style={{ padding: "4px 8px 14px" }}>
        <Logo small />
        <div className="muted" style={{ fontSize: 12 }}>Seu projeto elétrico, mais simples.</div>
      </div>
      {userName && (
        <div className="card" style={{ padding: 12, display: "flex", gap: 10, alignItems: "center", marginBottom: 10 }}>
          <span style={{
            width: 34, height: 34, borderRadius: "50%", background: "var(--blue)",
            display: "inline-flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 13,
          }}>{iniciais}</span>
          <span style={{ fontSize: 13.5 }}>{userName}</span>
        </div>
      )}
      {items.map((it) => {
        const active = path === it.href && !it.anchor;
        const href = it.anchor ? `${it.href}#${it.anchor}` : it.href;
        return (
          <Link key={it.label} href={href} className={`side-link ${active ? "active" : ""}`}>
            <span>{it.icon}</span> {it.label}
          </Link>
        );
      })}
      <div style={{ marginTop: "auto" }}>
        <button className="side-link" onClick={sair}>
          <span>🚪</span> Sair
        </button>
      </div>
    </aside>
  );
}