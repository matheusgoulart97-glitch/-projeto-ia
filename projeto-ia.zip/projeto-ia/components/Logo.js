export default function Logo({ small = false }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
      <svg width={small ? 26 : 34} height={small ? 26 : 34} viewBox="0 0 40 40">
        <defs>
          <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#ff3b3b" />
            <stop offset="1" stopColor="#ffb020" />
          </linearGradient>
        </defs>
        <path d="M4 30 L12 8 L20 24 L28 8 L36 30 L26 30 L22 18 L18 30 Z" fill="url(#lg)" />
        <path d="M22 6 L16 18 L20 18 L15 30 L27 14 L22 14 L26 6 Z" fill="#ffd166" stroke="#b45309" strokeWidth="0.6" />
      </svg>
      <span style={{ fontWeight: 800, fontSize: small ? 16 : 20 }}>
        Projeto <span style={{ color: "var(--cyan)" }}>IA</span>
      </span>
    </span>
  );
}
