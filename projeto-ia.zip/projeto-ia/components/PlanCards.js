import Link from "next/link";
import { PLANS } from "../lib/plans";

const themes = { blue: "blue", orange: "orange", purple: "purple" };
const btnClass = { blue: "btn btn-primary", orange: "btn btn-orange", purple: "btn btn-purple" };

export function PlanCard({ plan, onChoose }) {
  const inner = (
    <>
      <h3>{plan.name}</h3>
      <div className="muted">{plan.description}</div>
      <div className="plan-price">{plan.price}</div>
      <ul className="plan-feats">
        {plan.features.map((f) => (
          <li key={f}>{f}</li>
        ))}
      </ul>
      <span className={btnClass[themes[plan.theme]]}>{plan.cta}</span>
    </>
  );
  const cls = `card plan-card ${themes[plan.theme]}`;
  if (onChoose) {
    return (
      <div className={cls}>
        {inner}
        <div style={{ height: 12 }} />
        <button className={btnClass[themes[plan.theme]]} onClick={() => onChoose(plan.id)}>
          {plan.cta}
        </button>
      </div>
    );
  }
  return (
    <Link href={`/dashboard?plano=${plan.id}`} className={cls} style={{ display: "block" }}>
      {inner}
    </Link>
  );
}

export default function PlanCards({ onChoose }) {
  return (
    <div className="plans-grid">
      {PLANS.map((p) => (
        <PlanCard key={p.id} plan={p} onChoose={onChoose} />
      ))}
    </div>
  );
}
