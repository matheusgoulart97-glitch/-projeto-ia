-- ============================================================
-- Projeto IA — schema do banco (Supabase / Postgres)
-- Execute este arquivo no SQL Editor do Supabase.
-- ============================================================

create extension if not exists "pgcrypto";

-- Perfis do usuário (dados complementares ao auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text,
  role text check (role in ('cliente','profissional','conhecer')),
  plan text not null default 'gratis',
  created_at timestamptz not null default now()
);

-- Projetos elétricos
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  name text not null,
  project_type text not null default 'arquitetonica', -- arquitetonica | eletrico
  status text not null default 'rascunho',
  pdf_path text, -- caminho no Supabase Storage (bucket 'plantas')
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Ambientes marcados na planta
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects on delete cascade,
  name text not null,
  page int not null default 1,
  x numeric not null, -- coordenadas relativas 0..1 sobre a página do PDF
  y numeric not null,
  w numeric not null,
  h numeric not null
);

-- Pontos elétricos (interruptores, tomadas e pontos de luz)
create table if not exists public.points (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects on delete cascade,
  room_id uuid references public.rooms on delete set null,
  page int not null default 1,
  kind text not null, -- luz_teto | interruptor_simples | interruptor_paralelo | tomada_baixa | tomada_media | tomada_alta | quadro
  x numeric not null,
  y numeric not null,
  meta jsonb default '{}'::jsonb
);

-- Projetos anteriores usados como referência pela IA / sugestões
create table if not exists public.reference_templates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  name text not null,
  room_type text, -- ex.: quarto, sala, cozinha, banheiro
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Row Level Security: cada usuário só vê os próprios dados
alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.rooms enable row level security;
alter table public.points enable row level security;
alter table public.reference_templates enable row level security;

create policy "perfis: dono acessa" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "projetos: dono acessa" on public.projects for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "rooms: dono acessa" on public.rooms for all using (
  exists (select 1 from public.projects p where p.id = rooms.project_id and p.user_id = auth.uid())
) with check (
  exists (select 1 from public.projects p where p.id = rooms.project_id and p.user_id = auth.uid())
);
create policy "points: dono acessa" on public.points for all using (
  exists (select 1 from public.projects p where p.id = points.project_id and p.user_id = auth.uid())
) with check (
  exists (select 1 from public.projects p where p.id = points.project_id and p.user_id = auth.uid())
);
create policy "templates: dono acessa" on public.reference_templates for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Índice para agilizar consultas
create index if not exists idx_rooms_project on public.rooms (project_id);
create index if not exists idx_points_project on public.points (project_id);
create index if not exists idx_projects_user on public.projects (user_id);
